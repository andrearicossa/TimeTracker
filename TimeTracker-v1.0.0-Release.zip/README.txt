# Time Tracker v1.0.0

## Descrizione
Time Tracker è un'applicazione desktop WPF per il tracciamento delle attività giornaliere.

## Caratteristiche
- ✅ Creazione e gestione attività
- ✅ Timer integrato per tracciamento temporale
- ✅ Modifica completa con date e orari
- ✅ Salvataggio automatico in formato JSON
- ✅ Interfaccia moderna con icone
- ✅ Eliminazione sicura con conferma

## Requisiti di Sistema
- Windows 10/11
- .NET 9.0 Runtime (Windows Desktop)

## Installazione
1. Estrarre tutti i file dallo ZIP in una cartella
2. Eseguire `TimeTracker.exe`

## Utilizzo
1. **Nuova Attività**: Cliccare il pulsante "Nuovo" per creare un'attività
2. **Avvia Timer**: Cliccare l'icona ▶ per iniziare il cronometro
3. **Modifica**: Cliccare l'icona ✎ per modificare nome, durata e orari
4. **Elimina**: Cliccare l'icona ✖ per rimuovere un'attività

## File Inclusi
- `TimeTracker.exe` - Eseguibile principale
- `TimeTracker.dll` - Libreria applicazione
- `TimeTracker.deps.json` - Dipendenze
- `TimeTracker.runtimeconfig.json` - Configurazione runtime
- `TimeTracker.pdb` - Simboli di debug (opzionale)

## Note
- I dati vengono salvati automaticamente in `activities.json`
- L'applicazione non richiede installazione
- Per disinstallare, eliminare semplicemente la cartella

---
**Time Tracker v1.0.0** - © 2025 TimeTracker Development